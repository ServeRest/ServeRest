module.exports = {
  require: 'test/integration/utils/global.js',
  spec: ['test/integration/**/*.test.js'],
  timeout: 30000
}
